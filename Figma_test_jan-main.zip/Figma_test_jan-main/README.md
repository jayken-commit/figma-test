<<<<<<< HEAD
# Figma 텍스트 번역 및 UX 라이팅 플러그인

Figma 페이지의 모든 텍스트를 한 번에 번역하고 UX 라이팅으로 개선할 수 있는 플러그인입니다.

## 🏗️ 플러그인 아키텍처 및 컴파일 과정

### 프로젝트 구조
```
figma-text-translator/
├── manifest.json          # 피그마 플러그인 설정 파일
├── code.ts               # 메인 로직 (피그마 API와 상호작용)
├── ui.html               # 플러그인 UI (HTML/CSS/JavaScript)
├── ux-writer.ts          # UX 라이팅 개선 로직
├── translator.ts         # 번역 기능
├── prompt-config.ts      # AI 프롬프트 및 설정
├── webpack.config.js     # 빌드 설정
├── package.json          # 의존성 관리
└── dist/
    └── code.js           # 컴파일된 최종 파일
```

### 컴파일 과정 (TypeScript → JavaScript)

1. **개발 환경 설정**
   ```bash
   npm install  # 의존성 설치
   ```

2. **빌드 프로세스**
   ```bash
   npm run build  # TypeScript를 JavaScript로 컴파일
   ```
   
   **내부 동작:**
   - Webpack이 `code.ts`를 진입점으로 모든 TypeScript 파일을 분석
   - `ux-writer.ts`, `translator.ts`, `prompt-config.ts` 등을 하나로 번들링
   - 최종적으로 `dist/code.js` 파일 생성 (약 26KB)

3. **피그마 플러그인 구조**
   ```
   Figma Plugin = manifest.json + dist/code.js + ui.html
   ```

### 피그마에서의 실행 과정

#### 1. 플러그인 로드
```json
// manifest.json - 피그마가 읽는 설정 파일
{
  "name": "jan_test_ux",
  "main": "dist/code.js",    // 메인 로직 파일
  "ui": "ui.html",           // UI 파일
  "editorType": ["figma", "dev"],
  "networkAccess": {
    "allowedDomains": ["https://generativelanguage.googleapis.com"]
  }
}
```

#### 2. 실행 환경 분리
- **메인 스레드** (`dist/code.js`): 피그마 API 접근, 텍스트 수집/수정
- **UI 스레드** (`ui.html`): 사용자 인터페이스, 사용자 입력 처리

#### 3. 양방향 통신
```typescript
// code.ts (메인 스레드)
figma.showUI(__html__);  // UI 시작
figma.ui.postMessage({   // UI로 데이터 전송
  type: "texts-collected",
  texts: textData
});

// ui.html (UI 스레드)  
parent.postMessage({     // 메인으로 명령 전송
  pluginMessage: {
    type: "toggle-text",
    nodeId: "123"
  }
}, '*');
```

## 🚀 피그마에서 사용하기

### 설치 및 실행
1. **개발자 모드로 로드**
   - Figma 데스크톱 앱 실행
   - `Plugins` → `Development` → `Import plugin from manifest...`
   - 이 프로젝트 폴더의 `manifest.json` 선택

2. **플러그인 실행**
   - 텍스트가 있는 피그마 파일 열기
   - `Plugins` → `Development` → `jan_test_ux` 클릭

### 플러그인 동작 흐름

#### 1. 텍스트 수집 단계
```typescript
// code.ts에서 실행
function collectAllTextNodes() {
  // 현재 페이지의 모든 노드 순회
  // 텍스트 노드만 필터링
  // UI로 텍스트 목록 전송
}
```

#### 2. UX 라이팅 개선 단계
```typescript
// ux-writer.ts + prompt-config.ts
async function improveUxWriting(text: string) {
  // Google Gemini API 호출
  // 카카오모빌리티 스타일 가이드 적용
  // 4가지 원칙 기반 텍스트 개선
}
```

#### 3. 피그마 노드 업데이트
```typescript
// code.ts에서 실행
async function toggleTextContent(nodeId: string, useUxWriting: boolean) {
  const node = await figma.getNodeByIdAsync(nodeId);
  await figma.loadFontAsync(node.fontName);
  node.characters = useUxWriting ? improvedText : originalText;
}
```

### 주요 인터랙션 기능

#### 양방향 연동
- **피그마 → UI**: 텍스트 더블클릭 시 UI에서 해당 항목 하이라이트
- **UI → 피그마**: UI에서 텍스트 더블클릭 시 피그마에서 해당 노드로 포커스

#### 실시간 토글
- 원본 텍스트 ↔ UX 개선 텍스트 간 즉시 전환
- 개선 이유 호버 시 표시

## 문제 해결

### 자주 발생하는 문제

1. **프롬프트 응답이 이상해요**

   - `prompt-config.ts`의 `TEMPERATURE` 값을 0.1~0.3으로 낮춰보세요
   - 더 많은 예시 데이터를 `UX_GUIDE_EXAMPLES`에 추가하세요

2. **특정 용어가 제대로 변환되지 않아요**

   - 해당 용어의 변환 예시를 `UX_GUIDE_EXAMPLES`에 추가하세요
   - 프롬프트에 더 구체적인 지침을 추가하세요

3. **AI 응답이 너무 창의적이에요**
   - `TEMPERATURE`를 0.1로 낮춰보세요
   - 프롬프트에 "정확히 따라주세요" 같은 지침을 추가하세요

## 주의사항

- 번역 및 UX 라이팅 작업은 되돌릴 수 없습니다. 중요한 작업 전에는 백업을 만드세요
- 한 번에 많은 텍스트를 처리할 때는 시간이 걸릴 수 있습니다
- API 사용 시 요금이 발생할 수 있습니다
- 프롬프트 수정 후에는 빌드(`npm run build`)를 다시 실행하세요

## 🔧 기술적 세부사항

### 의존성 및 도구
- **TypeScript**: 타입 안전성과 개발 효율성
- **Webpack**: 모듈 번들링 및 코드 최적화  
- **Google Gemini API**: AI 기반 텍스트 개선
- **Figma Plugin API**: 피그마와의 네이티브 통합

### 빌드 설정 (webpack.config.js)
```javascript
module.exports = {
  entry: './code.ts',           // 진입점
  output: {
    filename: 'code.js',        // 출력 파일
    path: path.resolve(__dirname, 'dist')
  },
  resolve: {
    extensions: ['.ts', '.js']  // TypeScript 지원
  },
  module: {
    rules: [{
      test: /\.ts$/,
      use: 'ts-loader'          // TypeScript 컴파일러
    }]
  }
};
```

### 성능 최적화
- **청크 단위 처리**: 대용량 텍스트를 작은 단위로 나누어 API 호출
- **비동기 처리**: UI 블로킹 없이 백그라운드에서 텍스트 개선
- **캐싱**: 플러그인 데이터로 원본 텍스트 보존
- **에러 핸들링**: API 실패 시 폴백 메커니즘

### 메모리 및 상태 관리
```typescript
// 플러그인 데이터로 상태 보존
textNode.setPluginData("originalText", originalText);
textNode.setPluginData("isUxMode", "true");

// UI와 메인 스레드 간 상태 동기화
figma.ui.postMessage({
  type: "ux-texts-ready",
  uxTexts: improvedTexts
});
```

## 🐛 문제 해결

### 자주 발생하는 이슈
1. **"manifest error"**: `editorType`에 `"dev"` 포함 필요
2. **"UI가 안 보임"**: 텍스트가 있는 파일에서 실행 필요
3. **"네트워크 에러"**: API 키 설정 및 네트워크 권한 확인

### 개발 팁
- **DevTools 활용**: `View` → `Developer` → `Console`에서 에러 확인
- **캐시 클리어**: 피그마 앱 재시작으로 플러그인 캐시 초기화
- **점진적 테스트**: 작은 텍스트부터 시작해서 대용량 문서로 확장

## 📈 향후 개선 계획
- [ ] 더 많은 언어 지원 추가
- [ ] 사용자 커스텀 스타일 가이드 지원
- [ ] 텍스트 변경 히스토리 기능
- [ ] 배치 처리 성능 개선
- [ ] 오프라인 모드 지원

---

이 플러그인은 TypeScript로 개발되어 Webpack으로 번들링된 후, 피그마의 플러그인 런타임에서 실행됩니다. 메인 스레드와 UI 스레드 간의 메시지 패싱을 통해 안전하고 효율적인 텍스트 처리를 제공합니다.

## 라이선스

MIT License
=======
# Figma_test_jan
>>>>>>> 07346b9b32ed38f7a27ac22a0a81fc454e8c6df2
