// UX 라이팅 개선 전용 모듈
// 카카오모빌리티 UX 라이팅 가이드에 따라 텍스트를 개선합니다:
// 1. 쉬운 표현 사용 (한자어→순우리말, 어려운 표현→쉬운 표현)
// 2. 구어체로 친근하게 (문어체→구어체, 자연스러운 존댓말)
// 3. 사용자 중심 표현 (외래어→한국어, 업계용어→일반표현)
// 4. 간결하고 명확하게 (불필요한 표현 삭제, 명확한 표현)
import { getPrompt, API_CONFIG, ERROR_MESSAGES } from "./prompt-config";

/**
 * UX 라이팅을 개선합니다 (단일 텍스트 또는 배열 처리)
 */
async function improveUxWriting(text: string): Promise<string>;
async function improveUxWriting(texts: string[]): Promise<string[]>;
async function improveUxWriting(
  input: string | string[]
): Promise<string | string[]> {
  // 단일 텍스트인 경우 배열로 변환
  const isArray = Array.isArray(input);
  const texts = isArray ? input : [input];

  if (!texts || texts.length === 0) {
    return isArray ? [] : "";
  }

  const geminiKey = process.env.GEMINI_API_KEY;
  if (!geminiKey) {
    console.error(ERROR_MESSAGES.NO_API_KEY);
    const failedTexts = texts.map(
      (t) => t + ` (${ERROR_MESSAGES.IMPROVEMENT_FAILED})`
    );
    return isArray ? failedTexts : failedTexts[0];
  }

  try {
    const model = API_CONFIG.GEMINI_MODEL;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`;

    const prompt = getPrompt(true); // 항상 배치 처리 프롬프트 사용
    const userPrompt = `다음 텍스트 배열의 각 항목을 UX 라이팅 가이드에 따라 개선해주세요:\n\n${JSON.stringify(
      texts
    )}`;

    const bodyGemini = {
      systemInstruction: {
        parts: [{ text: prompt }],
      },
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }],
        },
      ],
      generationConfig: {
        temperature: API_CONFIG.TEMPERATURE,
        maxOutputTokens: API_CONFIG.BATCH_MAX_TOKENS,
        response_mime_type: "application/json",
      },
    };

    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bodyGemini),
    });

    if (!resp.ok) {
      const errorText = await resp.text();
      throw new Error(
        `${ERROR_MESSAGES.API_CALL_FAILED}: ${resp.status} ${errorText}`
      );
    }

    const data = await resp.json();
    let responseText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "[]";

    // AI가 응답에 ```json ... ``` 와 같은 마크다운을 포함하는 경우 순수 JSON만 추출
    const jsonMatch = responseText.match(/(\[[\s\S]*\])/);
    if (jsonMatch) {
      responseText = jsonMatch[0];
    } else {
      console.warn(ERROR_MESSAGES.INVALID_RESPONSE, responseText);
      const errorTexts = texts.map((t) => t + " (응답 형식 오류)");
      return isArray ? errorTexts : errorTexts[0];
    }

    try {
      const improvedTexts = JSON.parse(responseText);

      if (
        !Array.isArray(improvedTexts) ||
        improvedTexts.length !== texts.length
      ) {
        console.warn(
          `UX 라이팅 개선 결과가 유효한 배열이 아니거나 개수가 다릅니다. 원본: ${texts.length}, 결과: ${improvedTexts.length}`
        );
        const failedTexts = texts.map(
          (t) => t + ` (${ERROR_MESSAGES.IMPROVEMENT_FAILED})`
        );
        return isArray ? failedTexts : failedTexts[0];
      }

      // 단일 텍스트인 경우 첫 번째 결과만 반환
      return isArray ? improvedTexts : improvedTexts[0];
    } catch (parseError) {
      console.error(
        ERROR_MESSAGES.PARSING_FAILED,
        parseError,
        "원본 응답:",
        responseText
      );
      const errorTexts = texts.map((t) => t + " (파싱 오류)");
      return isArray ? errorTexts : errorTexts[0];
    }
  } catch (error) {
    console.error("UX 라이팅 개선 중 오류 발생:", error);
    const failedTexts = texts.map(
      (t) => t + ` (${ERROR_MESSAGES.IMPROVEMENT_FAILED})`
    );
    return isArray ? failedTexts : failedTexts[0];
  }
}

export { improveUxWriting };
